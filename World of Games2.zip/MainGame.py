from Live import load_game, welcome

print(welcome("Adir"))
load_game()
